from distutils.core import setup

setup(
name='nester',
version='1.0.0',
py_modules=['nester'],
author='Jack Zhu',
author_email='zhufengjack@gmail.com',
description='nester',
)
